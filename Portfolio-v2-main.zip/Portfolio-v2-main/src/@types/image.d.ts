declare module '*.svg';
declare module '*.pdf';
declare module '*.png';
declare module '*.jpg';
declare module '*.gif';
declare module '*.webp';